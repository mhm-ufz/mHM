mpiexec -n 4 ./simple_xy_par_wr
mpiexec -n 4 ./simple_xy_par_rd
