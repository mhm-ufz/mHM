mpiexec -n 4 ./tst_parallel2
