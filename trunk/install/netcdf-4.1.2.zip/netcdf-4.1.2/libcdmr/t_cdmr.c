/* This example program is part of Unidata's netCDF library for
   scientific data access. 

   How about a short, but meaningful, netCDF program?

   Ed Hartnett, 6/19/4
   $Id: simple.c,v 1.1 2004/07/26 14:04:42 ed Exp $
*/

#include <stdio.h>
#include <string.h>
#include <netcdf.h>

int
main()
{
    return 0;
}

